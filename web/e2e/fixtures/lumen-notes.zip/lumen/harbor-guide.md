# Lumen harbor guide

The ferry to North Quay leaves pier nine at seven bells.
Northwind keeps the spare lanterns in the eastern shed.
